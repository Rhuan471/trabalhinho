CREATE TABLE locations (
    street VARCHAR(40),
    city VARCHAR(30),
    state VARCHAR(25),
    country_id VARCHAR(2)
);
